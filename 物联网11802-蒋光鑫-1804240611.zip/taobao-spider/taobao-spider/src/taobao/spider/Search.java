package taobao.spider;

import java.io.File;
import java.io.FileOutputStream;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

public class Search {

   static PhoneDao phoneDao;
  static   Scanner scanner=new Scanner(System.in);


    static {
        try {
            phoneDao = new PhoneDao();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) throws Exception{
        int t;
        while (true) {
            System.out.println("*****�����ѯϵͳ*****");
            System.out.println("1.��ȡҳ����Ϣ");
            System.out.println("2.��ѯ���ݿ���Ϣ");
            System.out.println("3.���ݵ���");
            System.out.println("4.�˳�");
            System.out.println("������1-4");
            System.out.println("*********************");
            t=scanner.nextInt();
            switch (t){
                case 1:
                    PhoneSpider.spider();
                    break;
                case 2:
                    search();
                    break;
                case 3:
                    export();
                    break;
                case 4:System.exit(0);
            }
        }

    }

    public static void search() throws Exception {
        System.out.println("������۸�����");
        float a=scanner.nextFloat();
        System.out.println("������۸�����");
        float b=scanner.nextFloat();
        System.out.println("�������ѯ�ؼ���");
        String key=scanner.next();
        printPhoneList(phoneDao.query(a,b,key));
    }
    static void printPhoneList(List<Phone> phoneList){
        for (Phone p:phoneList
             ) {
            System.out.println(p);
        }
    }
    static void export()throws Exception{
        FileOutputStream out=new FileOutputStream("phone_export.txt");
        out.write(phoneDao.queryAll().toString().getBytes());
        out.flush();
        out.close();
        System.out.println("�������!");
    }
}
