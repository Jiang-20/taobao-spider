package taobao.spider;

public class Phone {
    private String name;
    private float price;
    private String sales;
    private String nick;
    private String pickURL;

    public Phone(String name, float price, String sales, String nick, String pickURL) {
        this.name = name;
        this.price = price;
        this.sales = sales;
        this.nick = nick;
        this.pickURL = pickURL;
    }
public Phone(){

}
    @Override
    public String toString() {
        return "Phone{" +
                "name='" + name + '\'' +
                ", price=" + price +
                ", sales='" + sales + '\'' +
                ", nick='" + nick + '\'' +
                ", pickURL='" + pickURL + '\'' +
                '}';
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public float getPrice() {
        return price;
    }

    public void setPrice(float price) {
        this.price = price;
    }

    public String getSales() {
        return sales;
    }

    public void setSales(String sales) {
        this.sales = sales;
    }

    public String getNick() {
        return nick;
    }

    public void setNick(String nick) {
        this.nick = nick;
    }

    public String getPickURL() {
        return pickURL;
    }

    public void setPickURL(String pickURL) {
        this.pickURL = pickURL;
    }
}
