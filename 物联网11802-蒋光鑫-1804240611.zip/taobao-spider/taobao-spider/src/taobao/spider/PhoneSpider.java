package taobao.spider;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import org.jsoup.Jsoup;

import java.io.BufferedReader;
import java.io.FileReader;

public class PhoneSpider {
    public static final String referer = "https://www.taobao.com/";
    public static PhoneDao phoneDao = null;

    static {
        try {
            phoneDao = new PhoneDao();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) throws Exception {
        spider();
    }

    public static void spider() throws Exception {
        System.out.println("1");
        BufferedReader bufferedReader = new BufferedReader(new FileReader("Cookies"));
        final String COOKIE = bufferedReader.readLine();
        System.out.println(COOKIE);
        String baseURL = "https://s.taobao.com/search?q=%E6%89%8B%E6%9C%BA&imgfile=&commend=all&ssid=s5-e&search_type=item&sourceId=tb.index&spm=a21bo.2017.201856-taobao-item.1&ie=utf8&initiative_id=tbindexz_20170306&bcoffset=3&ntoffset=3&p4ppushleft=1%2C48&s=";
        int pageNum = 44;
        for (int i = 0; i < 100; i++) {

            String json = Jsoup.connect(baseURL + pageNum * i)
                    .referrer(referer)
                    .header("accept", "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9")
                    .header("cookie", COOKIE)
                    .get()
                    .select("head > script")
                    .get(7)
                    .toString()
                    .replaceAll(" ", "")
                    .split("g_srp_loadCss")[0]
                    .split("g_page_config")[1]
                    .substring(1);
            json=json.substring(0,json.length()-2);
            System.out.println(json);
            JSONObject obj=JSONObject.parseObject(json);
            JSONArray itemArray=obj.getJSONObject("mods")
                    .getJSONObject("itemlist")
                    .getJSONObject("data")
                    .getJSONArray("auctions");
            for (int j = 0; j < itemArray.size(); j++) {
                JSONObject item=itemArray.getJSONObject(j);
                //��Ʒ����
                String name=item.getString("raw_title");
                //�۸�
                float price=item.getFloatValue("view_price");
                //��������
                String sales=item.getString("view_sales");
                //ͼƬ����
                String picURL="https:"+item.getString("pic_url");
                //����
                String nick=item.getString("nick");
                System.out.println(name);
                System.out.println(price);
                System.out.println(sales);
                System.out.println(picURL);
                System.out.println(nick);
                phoneDao.insert(name,price,sales,nick,picURL);
            }
            try {
                Thread.sleep(2*1000);
            }catch (Exception e){
                e.printStackTrace();
            }
        }
    }
}