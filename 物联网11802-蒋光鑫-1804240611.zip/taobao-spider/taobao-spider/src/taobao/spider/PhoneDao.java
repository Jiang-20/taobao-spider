package taobao.spider;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class PhoneDao {
    private static final String jdbcURL="jdbc:mysql://losthost:3306/taobao?useUnicode=true&amp&characterEncoding=utf-8";
    private static final String user="root";
    private static final String password="149920";
    private Statement stat;
    public PhoneDao()throws Exception{
        System.out.println("phone construct");
        Connection conn = null;

        // ע������
        Class.forName("com.mysql.jdbc.Driver");

        // ��������
        conn = (Connection) DriverManager.getConnection(jdbcURL,user,password);
        stat = conn.createStatement();
    }
    public void insert(String name, float price, String sales, String nick, String pickURL) throws Exception{
        name=cleanStr(name);
        sales=cleanStr(sales);
        nick=cleanStr(nick);
        pickURL=cleanStr(pickURL);
        String sql = "INSERT INTO phone(name,price,sales,nick,picURL) VALUES('"+name+"',"+price+",'"+sales+"','"+nick+"','"+pickURL+"')";
        System.out.println(sql);
        stat.execute(sql);
    }
    public List<Phone> query(float p1,float p2,String name)throws Exception {
        String sql = "";
        if (name != null)
            sql = "SELECT * FROM phone WHERE name LIKE '%" + name + "%' AND price BETWEEN " + p1 + " AND " + p2;
        else
            sql = "SELECT * FROM phone WHERE price BETWEEN " + p1 + " AND " + p2;
        System.out.println(sql);
        ResultSet resultSet = stat.executeQuery(sql);
        List<Phone> phones = new ArrayList<>();
        while (resultSet.next()) {
            String n = resultSet.getString("name");
            float price = resultSet.getFloat("price");
            String sales = resultSet.getString("sales");
            String nick = resultSet.getString("nick");
            String picURL = resultSet.getString("picURL");
            Phone phone = new Phone(n, price, sales, nick, picURL);
            phones.add(phone);
        }
        return phones;
    }
    public List<Phone> queryAll()throws Exception {
            String sql = "SELECT * from phone";
            ResultSet resultSet = stat.executeQuery(sql);
            List<Phone> phones = new ArrayList<>();
            while (resultSet.next()) {
                String n = resultSet.getString("name");
                float price = resultSet.getFloat("price");
                String sales = resultSet.getString("sales");
                String nick = resultSet.getString("nick");
                String picURL = resultSet.getString("picURL");
                Phone phone = new Phone(n, price, sales, nick, picURL);
                phones.add(phone);
            }

            return phones;
    }
    public String cleanStr(String name){
        if (name==null)return name;
        name=name.replaceAll("'","");
        name=name.replaceAll("\"","");
        return name;
    }
}
